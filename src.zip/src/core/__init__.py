"""
SCADA Scout Module
"""
